import algorithms_project_file
import random
import timeit

def insertion_linear_search(arr, target):
    sorted_arr = algorithms_project_file.insertion_sort(arr)
    result = algorithms_project_file.linear_search(sorted_arr, target)
    return result


def bubble_linear_search(arr, target):
    sorted_arr = algorithms_project_file.bubble_sort(arr)
    result = algorithms_project_file.linear_search(sorted_arr, target)
    return result


def insertion_binary_search(arr, target):
    sorted_arr = algorithms_project_file.insertion_sort(arr)
    result = algorithms_project_file.binary_search(sorted_arr, target)
    return result


def bubble_binary_search(arr, target):
    sorted_arr = algorithms_project_file.bubble_sort(arr)
    result = algorithms_project_file.binary_search(sorted_arr, target)
    return result


def main():
    # Example usage:
    unsorted_list = [random.randint(1, 1000) for _ in range(100000)]
    target = random.randint(1, 1000)

    insertion_linear_time = timeit.timeit(lambda: insertion_linear_search(unsorted_list.copy(), target), number=1)
    bubble_linear_time = timeit.timeit(lambda: bubble_linear_search(unsorted_list.copy(), target), number=1)
    insertion_binary_time = timeit.timeit(lambda: insertion_binary_search(unsorted_list.copy(), target), number=1)
    bubble_binary_time = timeit.timeit(lambda: bubble_binary_search(unsorted_list.copy(), target), number=1)

    print(f"Insertion Sort + Linear Search Execution Time: {insertion_linear_time:.6f} seconds")
    print(f"Bubble Sort + Linear Search Execution Time: {bubble_linear_time:.6f} seconds")
    print(f"Insertion Sort + Binary Search Execution Time: {insertion_binary_time:.6f} seconds")
    print(f"Bubble Sort + Binary Search Execution Time: {bubble_binary_time:.6f} seconds")
    

if __name__ == "__main__":
    main()