import tkinter as tk
from tkinter import messagebox

NODE_WIDTH = 80
NODE_HEIGHT = 40
VERTICAL_GAP = 10
CANVAS_WIDTH = 300
CANVAS_HEIGHT = 500

class QueueVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Queue Visualizer")

        self.queue = []

        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg='white')
        self.canvas.pack(pady=20)

        control_frame = tk.Frame(root)
        control_frame.pack()

        tk.Label(control_frame, text="Queue Value:").grid(row=0, column=0)
        self.queue_entry = tk.Entry(control_frame, width=10)
        self.queue_entry.grid(row=0, column=1)

        queue_btn = tk.Button(control_frame, text="Queue", command=self.queue_enqueue)
        queue_btn.grid(row=0, column=2, padx=5)

        dequeue_btn = tk.Button(control_frame, text="Dequeue", command=self.queue_dequeue)
        dequeue_btn.grid(row=1, column=2, pady=5)

        self.status_label = tk.Label(root, text="", fg="blue", font=("Arial", 12))
        self.status_label.pack(pady=5)

        self.draw_queue()

    def draw_node(self, x, y, data):
        rect = self.canvas.create_rectangle(x, y, x + NODE_WIDTH, y + NODE_HEIGHT, fill="lightblue", outline="black", width=2)
        self.canvas.create_text(x + NODE_WIDTH/2, y + NODE_HEIGHT/2, text=str(data), font=("Arial", 16))
        return rect

    def draw_queue(self):
        self.canvas.delete("all")
        x = (CANVAS_WIDTH - NODE_WIDTH) // 2
        y = CANVAS_HEIGHT - NODE_HEIGHT - 10
        for val in self.queue:
            self.draw_node(x, y, val)
            y -= NODE_HEIGHT + VERTICAL_GAP
        # Draw label for front of the queue
        if self.queue:
            self.canvas.create_text(x + NODE_WIDTH + 40, CANVAS_HEIGHT - NODE_HEIGHT - 10, text="Front", font=("Arial", 12), fill="red")

    def queue_enqueue(self):
        try:
            val = int(self.queue_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter an integer value to enqueue.")
            return
        self.queue.append(val)
        self.queue_entry.delete(0, tk.END)
        self.status_label.config(text=f"Enqueued {val} into queue")
        self.draw_queue()


    def queue_dequeue(self):
        if len(self.queue) == 0:
            messagebox.showinfo("Empty Queue", "Queue is empty. Cannot dequeue.")
            return
        val = self.queue.pop(0)
        self.status_label.config(text=f"Dequeued {val} from queue")
        self.draw_queue()

if __name__ == "__main__":
    root = tk.Tk()
    app = QueueVisualizer(root)

    # Example test cases:
    # app.queue = [10, 20, 30]
    # app.draw_queue()
    root.mainloop()
