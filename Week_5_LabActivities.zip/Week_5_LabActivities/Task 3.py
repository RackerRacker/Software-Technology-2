# Task 3 Tower of Hanoi
def task3():
    n = eval(input("Enter number of disks: "))
    moves = 2 ** n - 1
    # Find the solution recursively
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')
    print(f"Number of moves is {moves}")

# Used for Task 3: Tower of Hanoi
def moveDisks(n, fromTower, toTower, auxTower):
    if n == 1: # Stopping condition
        return

    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        moveDisks(n - 1, auxTower, toTower, fromTower)

if __name__ == "__main__":
    task3()