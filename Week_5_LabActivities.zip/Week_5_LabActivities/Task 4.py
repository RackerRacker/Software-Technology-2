def task4():
    print("Task 4: Sierpinski Triangle and Koch Snowflake")
    n = eval(input("Run sierpinski_triangle.py (1) or koch_snowflake.py (2): "))
    if n == 1:
        import sierpinski_triangle
    elif n == 2:
        import koch_snowflake
    else:
        print("Invalid choice. Please enter 1 or 2.")
