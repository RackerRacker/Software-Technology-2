from tkinter import *
import math

class KochSnowflake:
    def __init__(self):
        window = Tk()
        window.title("Koch Snowflake")
        self.width = 200
        self.height = 200
        self.canvas = Canvas(window, width=self.width, height=self.height)
        self.canvas.pack()

        # Add a label, an entry, and a button to frame1
        frame1 = Frame(window)
        frame1.pack()
        Label(frame1, text="Enter an order: ").pack(side=LEFT)
        self.order = StringVar()
        Entry(frame1, textvariable=self.order, justify=RIGHT).pack(side=LEFT)
        Button(frame1, text="Display Koch Snowflake", 
        command=self.display).pack(side=LEFT)
        window.mainloop()

    def display(self):
        self.canvas.delete("line")
        # Validate the input order
        try:
            order = int(self.order.get())
        except ValueError:
            return

        # Define the three corners of the equilateral triangle
        p1 = [self.width / 2, 20]
        p2 = [20, self.height - 50]
        p3 = [self.width - 20, self.height - 50]

        self.drawKochEdge(order, p1, p2)
        self.drawKochEdge(order, p2, p3)
        self.drawKochEdge(order, p3, p1)

    def drawKochEdge(self, order, p1, p2):
        if order == 0:
            # Base condition: draw a simple line
            self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags="line")
        else:
            #Calculate the vector from p1 to p2
            dx = p2[0] - p1[0]
            dy = p2[1] - p1[1]

            #Dividing the line into 3 parts
            x = [p1[0] + dx / 3, p1[1] + dy / 3]
            z = [p1[0] + 2 * dx / 3, p1[1] + 2 * dy / 3]

            # This creates the "bump" in the middle of the segment
            y_x = (x[0] + z[0]) / 2 + (math.sqrt(3) / 6) * (p1[1] - p2[1])
            y_y = (x[1] + z[1]) / 2 + (math.sqrt(3) / 6) * (p2[0] - p1[0])
            y = [y_x, y_y]

            # Recursively draw the 4 segments that make up the new line
            self.drawKochEdge(order - 1, p1, x)
            self.drawKochEdge(order - 1, x, y)
            self.drawKochEdge(order - 1, y, z)
            self.drawKochEdge(order - 1, z, p2)

KochSnowflake()