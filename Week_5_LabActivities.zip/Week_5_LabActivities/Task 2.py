# Task 2
import random
import timeit

import recursion_mergesort

def task2():
    sizes = [100, 1000, 5000]
    print(f"{'Size':<10} | {'Insertion (s)':<15} | {'Merge (s)':<15}")
    print("-" * 45)

    for size in sizes:
        test_data = [random.randint(1, 10000) for _ in range(size)]
        
        t_ins = timeit.timeit(lambda: recursion_mergesort.insertion_sort(test_data[:]), number=10)
        t_mrg = timeit.timeit(lambda: recursion_mergesort.merge_sort(test_data[:]), number=10)
        
        print(f"{size:<10} | {t_ins:<15.5f} | {t_mrg:<15.5f}")

if __name__ == "__main__":     
    task2()