import timeit
import random
import recursion_mergesort

# At its core, recursion involves solving a problem 
# by breaking it down into smaller, more manageable instances of the same problem. 

# BASIC RECURSION EXAMPLE
def sum_recursive(n):
    if n == 1:
        return 1 # Base case
    else:
        return n + sum_recursive(n - 1) # Recursive case
    

# RECURSIVELY CALCULATING FIBONACCI SEQUENCE (more difficult example)
# f(n) = f(n - 1) + f(n - 2)
def fibonacci_recursive(num1):
    if num1 <= 0:
        return 0 # Base case
    elif num1 == 1:
        return 1 # Base case 
    else:
        return fibonacci_recursive(num1 - 1) + fibonacci_recursive(num1 - 2) # Recursive case


# CHALLENGE: Use recursion to calculate the factorial.
def factorial_recursive(n):
    """
    Recursive function to calculate the factorial of a non-negative integer.

    Args:
    n (int): Non-negative integer for which factorial is calculated.

    Returns:
    int: Factorial of the input integer.
    """
    if n == 0:
        return 1  # Base case: factorial of 0 is 1
    else:
        return n * factorial_recursive(n - 1)  # Recursive case: n! = n * (n-1)!


# Iterative implementations of the same functions for comparison
def sum_iterative(n):
    result = 0
    for i in range(1, n + 1):
        result += i
    return result


def factorial_iterative(n):
    if n == 0:
        return 1
    else:
        result = 1
        for i in range(1, n + 1):
            result *= i
        return result
    

def fibonacci_iterative(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    else:
        a, b = 0, 1
        for _ in range(2, n + 1):
            a, b = b, a + b
        return b

def task1():
    print("Task 1: Recursion vs Iteration Performance Comparison")

    sizes = [10,20,30]

    print("SUM OF NATURAL NUMBERS")
    for n in sizes:
        rec_time = timeit.timeit(lambda: sum_recursive(n), number=10)
        iter_time = timeit.timeit(lambda: sum_iterative(n), number=10)
        print(f"n={n}: Recursive time: {rec_time:.6f} seconds, Iterative time: {iter_time:.6f} seconds")
    
    print("\nFIBONACCI")
    for n in sizes:
        rec_time = timeit.timeit(lambda: fibonacci_recursive(n), number=10)
        iter_time = timeit.timeit(lambda: fibonacci_iterative(n), number=10)
        print(f"n={n}: Recursive time: {rec_time:.6f} seconds, Iterative time: {iter_time:.6f} seconds")

    print("\nFACTORIAL")
    for n in sizes:
        rec_time = timeit.timeit(lambda: factorial_recursive(n), number=10)
        iter_time = timeit.timeit(lambda: factorial_iterative(n), number=10)
        print(f"n={n}: Recursive time: {rec_time:.6f} seconds, Iterative time: {iter_time:.6f} seconds")

if __name__ == "__main__":
    task1()